<?php
include 'config.php';
session_start();
if(isset($_REQUEST['Submit'])!='')
{
   $a=$_REQUEST['email'];
   $b=$_REQUEST['pass'];
   $sql="select * from scraper where email ='".$a."' AND password= '".$b."'";

$a1="";
$p1="";
$a2="";
$v2="";
//================================

$result1=mysqli_query($conn,$sql);
if(!$result1)
{
	echo "invalid <br>";
}
else{
	while($r=mysqli_fetch_array($result1))
	{
		$a1=$r[7];
		$phone=$r[8];
		$p1=$r[9];
		$a2=$r[11];
		$v2=$r[12];
	}	
}

if($a1==$a and $p1==$b and $a2==1 and $v2==1)
	
	{	
		$_SESSION['scraper']=$a;
		echo "valid user";
		header("Location:scrapsetailsl.php");
	}
	else
	{
		
		echo "Please enter correct username and password";
		//echo $sqle;
	}
}
$conn->close();
?>