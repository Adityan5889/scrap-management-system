-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 08, 2019 at 12:39 PM
-- Server version: 10.1.9-MariaDB
-- PHP Version: 5.5.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `scrapper`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `username` varchar(15) NOT NULL,
  `password` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`username`, `password`) VALUES
('admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `e_id` int(11) NOT NULL,
  `fname` varchar(20) DEFAULT NULL,
  `lname` varchar(25) DEFAULT NULL,
  `address` varchar(40) DEFAULT NULL,
  `city` varchar(20) DEFAULT NULL,
  `district` varchar(20) DEFAULT NULL,
  `pan` varchar(10) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `mobile` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `granualsmaster`
--

CREATE TABLE `granualsmaster` (
  `id` int(11) NOT NULL,
  `type` varchar(25) NOT NULL,
  `ton` int(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `granualsmaster`
--

INSERT INTO `granualsmaster` (`id`, `type`, `ton`) VALUES
(1, 'Plastic', 0),
(2, 'Glass', 1),
(3, 'EWaste', 3),
(4, 'PaperWaste', 0);

-- --------------------------------------------------------

--
-- Table structure for table `gst`
--

CREATE TABLE `gst` (
  `id` int(11) NOT NULL,
  `type` varchar(20) DEFAULT NULL,
  `rate` varchar(3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gst`
--

INSERT INTO `gst` (`id`, `type`, `rate`) VALUES
(1, 'Plastic', '3'),
(2, 'Glass', '2'),
(3, 'EWaste', '3.5'),
(4, 'PaperWaste', '1.7');

-- --------------------------------------------------------

--
-- Table structure for table `pricelist`
--

CREATE TABLE `pricelist` (
  `pid` int(11) NOT NULL,
  `type` varchar(20) DEFAULT NULL,
  `rate` varchar(3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pricelist`
--

INSERT INTO `pricelist` (`pid`, `type`, `rate`) VALUES
(1, 'Plastic', '11'),
(2, 'Glass', '15'),
(3, 'EWaste', '22'),
(4, 'PaperWaste', '9');

-- --------------------------------------------------------

--
-- Table structure for table `retailer`
--

CREATE TABLE `retailer` (
  `r_id` int(11) NOT NULL,
  `fname` varchar(20) DEFAULT NULL,
  `lname` varchar(25) DEFAULT NULL,
  `cname` varchar(50) DEFAULT NULL,
  `address` varchar(40) DEFAULT NULL,
  `city` varchar(20) DEFAULT NULL,
  `district` varchar(20) DEFAULT NULL,
  `state` varchar(20) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `mobile` varchar(10) DEFAULT NULL,
  `gst` varchar(20) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL,
  `otp` varchar(6) DEFAULT NULL,
  `activate` int(1) DEFAULT NULL,
  `validate` int(1) DEFAULT NULL,
  `reid` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `retailer`
--

INSERT INTO `retailer` (`r_id`, `fname`, `lname`, `cname`, `address`, `city`, `district`, `state`, `email`, `mobile`, `gst`, `password`, `otp`, `activate`, `validate`, `reid`) VALUES
(5, 'Rushikesh', 'Deshpande', 'Anand Electronics', 'At Post Medha Tal Jaoli', 'Medha', 'Satara', 'Maharashtra', 'deshpanderushikesh11@gmail.com', '9975014146', '123456789', '123', '636413', 1, 1, 'RETI05');

-- --------------------------------------------------------

--
-- Table structure for table `scraper`
--

CREATE TABLE `scraper` (
  `s_id` int(11) NOT NULL,
  `fname` varchar(20) DEFAULT NULL,
  `lname` varchar(15) DEFAULT NULL,
  `address` varchar(40) DEFAULT NULL,
  `city` varchar(40) DEFAULT NULL,
  `district` varchar(20) DEFAULT NULL,
  `state` varchar(20) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `mobile` varchar(10) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL,
  `otp` varchar(6) DEFAULT NULL,
  `activate` int(1) DEFAULT NULL,
  `validate` int(1) DEFAULT NULL,
  `scid` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `scraper`
--

INSERT INTO `scraper` (`s_id`, `fname`, `lname`, `address`, `city`, `district`, `state`, `email`, `mobile`, `password`, `otp`, `activate`, `validate`, `scid`) VALUES
(5, 'Shubham', 'Jadhav', 'C2 Telephone Quarters Vivekanand Nagar', 'Phaltan', 'Satara', 'Maharashtra', 'shubham242862@gmail.com', '9404233321', '123', '768289', 1, 1, 'SCRP05');

-- --------------------------------------------------------

--
-- Table structure for table `scrapmaster`
--

CREATE TABLE `scrapmaster` (
  `id` int(11) NOT NULL,
  `type` varchar(25) DEFAULT NULL,
  `ton` int(3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `scrapmaster`
--

INSERT INTO `scrapmaster` (`id`, `type`, `ton`) VALUES
(1, 'Plastic', 0),
(2, 'Glass', 0),
(3, 'EWaste', 0),
(4, 'PaperWaste', 0);

-- --------------------------------------------------------

--
-- Table structure for table `t9404233321`
--

CREATE TABLE `t9404233321` (
  `id` int(11) NOT NULL,
  `type` varchar(20) DEFAULT NULL,
  `ton` int(3) DEFAULT NULL,
  `validate` int(1) DEFAULT NULL,
  `Datee` text,
  `invcscid` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `t9404233321`
--

INSERT INTO `t9404233321` (`id`, `type`, `ton`, `validate`, `Datee`, `invcscid`) VALUES
(1, 'Plastic', 1, 1, '08-03-2019', 'INVCSCID01'),
(2, 'Glass', 3, 1, '08-03-2019', 'INVCSCID02'),
(3, 'EWaste', 4, 1, '08-03-2019', 'INVCSCID03'),
(4, 'PaperWaste', 18, 1, '08-03-2019', 'INVCSCID04');

-- --------------------------------------------------------

--
-- Table structure for table `t9975014146`
--

CREATE TABLE `t9975014146` (
  `id` int(11) NOT NULL,
  `type` varchar(20) DEFAULT NULL,
  `ton` int(3) DEFAULT NULL,
  `validate` int(1) DEFAULT NULL,
  `Datee` text,
  `invcreid` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `t9975014146`
--

INSERT INTO `t9975014146` (`id`, `type`, `ton`, `validate`, `Datee`, `invcreid`) VALUES
(1, 'Plastic', 1, 1, '08-03-2019', 'INVCREID01'),
(2, 'Glass', 2, 1, '08-03-2019', 'INVCREID02'),
(3, 'EWaste', 1, 1, '08-03-2019', 'INVCREID03'),
(4, 'PaperWaste', 18, 1, '08-03-2019', 'INVCREID04');

-- --------------------------------------------------------

--
-- Table structure for table `totalgranuals`
--

CREATE TABLE `totalgranuals` (
  `id` int(11) NOT NULL,
  `type` varchar(20) DEFAULT NULL,
  `ton` varchar(3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `totalgranuals`
--

INSERT INTO `totalgranuals` (`id`, `type`, `ton`) VALUES
(1, 'Plastic', '1'),
(2, 'Glass', '2'),
(3, 'EWaste', '1'),
(4, 'PaperWaste', '18');

-- --------------------------------------------------------

--
-- Table structure for table `totalscrap`
--

CREATE TABLE `totalscrap` (
  `id` int(11) NOT NULL,
  `type` varchar(20) DEFAULT NULL,
  `ton` varchar(3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `totalscrap`
--

INSERT INTO `totalscrap` (`id`, `type`, `ton`) VALUES
(1, 'Plastic', '1'),
(2, 'Glass', '3'),
(3, 'EWaste', '4'),
(4, 'PaperWaste', '18');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`e_id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `mobile` (`mobile`);

--
-- Indexes for table `granualsmaster`
--
ALTER TABLE `granualsmaster`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gst`
--
ALTER TABLE `gst`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `type` (`type`);

--
-- Indexes for table `pricelist`
--
ALTER TABLE `pricelist`
  ADD PRIMARY KEY (`pid`),
  ADD UNIQUE KEY `type` (`type`);

--
-- Indexes for table `retailer`
--
ALTER TABLE `retailer`
  ADD PRIMARY KEY (`r_id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `mobile` (`mobile`),
  ADD UNIQUE KEY `gst` (`gst`);

--
-- Indexes for table `scraper`
--
ALTER TABLE `scraper`
  ADD PRIMARY KEY (`s_id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `mobile` (`mobile`);

--
-- Indexes for table `scrapmaster`
--
ALTER TABLE `scrapmaster`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `type` (`type`);

--
-- Indexes for table `t9404233321`
--
ALTER TABLE `t9404233321`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `t9975014146`
--
ALTER TABLE `t9975014146`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `totalgranuals`
--
ALTER TABLE `totalgranuals`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `type` (`type`);

--
-- Indexes for table `totalscrap`
--
ALTER TABLE `totalscrap`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `type` (`type`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `e_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `granualsmaster`
--
ALTER TABLE `granualsmaster`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `gst`
--
ALTER TABLE `gst`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `pricelist`
--
ALTER TABLE `pricelist`
  MODIFY `pid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `retailer`
--
ALTER TABLE `retailer`
  MODIFY `r_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `scraper`
--
ALTER TABLE `scraper`
  MODIFY `s_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `scrapmaster`
--
ALTER TABLE `scrapmaster`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `t9404233321`
--
ALTER TABLE `t9404233321`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `t9975014146`
--
ALTER TABLE `t9975014146`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `totalgranuals`
--
ALTER TABLE `totalgranuals`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `totalscrap`
--
ALTER TABLE `totalscrap`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
