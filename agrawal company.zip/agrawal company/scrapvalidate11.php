<?php
include 'config.php';
session_start();
$a=$_SESSION['mobile'];

$b=$_POST['id'];
$c=$_POST['type'];
if(isset($_REQUEST['Submit'])!='')
{
				
				$sql="select * from t$a where id ='".$b."'";
				$sqlf="select * from scrapmaster where type='".$c."'";
				
				$a1="";
				$p1="";
				$v1="";
				$result=0;
				
				$result2=mysqli_query($conn,$sqlf);
				$result1=mysqli_query($conn,$sql);
				
				if(!$result1)
				{
					echo "invalid <br>";
				}
				else{
					while($r=mysqli_fetch_array($result1))
					{
						$phone=$r[0];
						$a1=$r[2];
					}	
					while($r1=mysqli_fetch_array($result2))
					{
						$typee=$r1[1];
						$res=$r1[2];
					}
					
				if($phone==$b)
					
					{
						$result=$a1+$res;
						
						$sql1="update t$a set validate='1' where id='".$b."'";
						$sqlff="update scrapmaster set ton=".$result." where type='".$typee."'";
						
						if ($conn->query($sql1) === TRUE and $conn->query($sqlff) === TRUE) 
						{
							echo "<script> alert('Account validated successfully');document.location='final_scrap_validation.php'</script>";
						}
			    		else
						{
							echo "Account not validated successfully";
						}
					}
					else
					{
						echo "Please enter correct email id";
					}
	
				}
				$conn->close();
				}
?>