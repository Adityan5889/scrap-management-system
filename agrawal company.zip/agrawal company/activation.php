<?php
include 'config.php';
if(isset($_REQUEST['Submit'])!='')
{
 $a=$_REQUEST['activation'];
 $sql="select * from scraper where otp ='".$a."'";

$a1="";
$p1="";
//================================

$result1=mysqli_query($conn,$sql);
if(!$result1)
{
	echo "invalid <br>";
}
else{
	while($r=mysqli_fetch_array($result1))
	{
		$a1=$r[10];
		$p1=$r[12];
	}	
}
if($a1==$a AND $p1==0)
	
	{
		$p1=1;
		$sql1="update scraper set activate='".$p1."' where otp='".$a1."'";
		if ($conn->query($sql1) === TRUE) 
		{
			echo "<script> alert('Account activated successfully pending for Admin Approval');document.location='index.html'</script>";
			//echo "Account activated successfully";
			//header("Location:index.html");
		}
		else
		{
			echo "Account not activated successfully";
		}
	}
	else
	{
		echo "Please enter correct username and password";
	}
	}
$conn->close();
?>