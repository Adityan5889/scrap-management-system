<?php
include 'config.php';

$a=$_POST['email'];
if(isset($_REQUEST['Submit'])!='')
{
				$a=$_POST['email'];
				$sql="select * from employee where email ='".$a."'";
				$a1="";
				$p1="";
				$v1="";
				$result1=mysqli_query($conn,$sql);
				if(!$result1)
				{
					echo "invalid <br>";
				}
				else{
					while($r=mysqli_fetch_array($result1))
					{
						$a1=$r[7];
					}	
					}
				if($a1==$a)
					
					{
						$sql1="delete from employee where email='".$a1."'";
						if ($conn->query($sql1) === TRUE) 
						{
							echo "<script> alert('Employee Deleted successfully');document.location='deleteemployee.php'</script>";
			    		}
						else
						{
							echo "Employee not deleted successfully";
						}
					}
					else
					{
						echo "Please enter correct email id";
					}
	
				}
				$conn->close();
?>