<?php
include 'config.php';
if(isset($_REQUEST['Submit'])!='')
{
	$a=$_REQUEST['username'];
	$b=$_REQUEST['password'];
	$sql="insert into admin (username,password) values('".$a."', '".$b."')";
if ($conn->query($sql) === TRUE) {
 echo "<script> alert('User Added successfully');document.location='adminpanel.html'</script>";
 } else {
    echo "Error: " . $sql . "<br>" . $conn->error;
	}
}
$conn->close();
?>