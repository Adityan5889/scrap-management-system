<?php
include 'config.php';
session_start(); 
if(isset($_REQUEST['Submit'])!='')
{

	$a=$_REQUEST['username'];
	$b=$_REQUEST['password'];
    $sql="select * from admin where username ='".$a."' ";

$a1="";
$p1="";
//================================

$result1=mysqli_query($conn,$sql);
if(!$result1)
{
	echo "invalid <br>";
}
else{
	while($r=mysqli_fetch_array($result1))
	{
		$a1=$r[0];
		$p1=$r[1];
	}	
}
if($a1==$a and $p1==$b)
	
	{
		$_SESSION['admin']=$a;
		echo "valid user";
        header("Location:adminpanel.html");
      
	}
	else
	{
		echo "Please enter correct username and password";
	}

}

$conn->close();
?>