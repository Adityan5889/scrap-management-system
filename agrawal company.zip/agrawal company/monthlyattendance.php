<html>	

<?php
include 'config.php';
				
					$date=date('d-m-y');
					$result1 = mysqli_query($conn,"select count(distinct ae_id) from attendance");
					$row = mysqli_fetch_row($result1);
					$max=$row[0];
				?>
				<table>
                <thead>
                  <tr>
                    <th>EmpID</th>
					<th>Total Present Days</th>
                  </tr>
                </thead>
                <tfoot>
                  <tr>
                    <th>EmpID</th>
					<th>Total Present Days</th>
                  </tr>
                </tfoot>
                <tbody>
                  <?php 
            //records as in an array
					
					$query="select distinct(ae_id) from attendance where datee<='".$date."' and value='present'";
					$result=mysqli_query($conn,$query);
					$num_rows = mysqli_num_rows($result);
			
					foreach( $result as $data ) // using foreach  to display each element of array
					{
						$q="select count(distinct datee,ae_id) from attendance where datee<='".$date."' and value='present' and ae_id='".$data['ae_id']."'";
						$result2 = mysqli_query($conn,$q);
						$ro = mysqli_fetch_row($result2);
						$max1=$ro[0];
					
						echo "<tr>
                          <td>".$data['ae_id']."</td>
						  <td>".$max1."</td>
                      </tr>"; 
					}
				       ?>		  
                </tbody>
              </table>
					</html>