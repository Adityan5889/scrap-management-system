<?php
include 'config.php';
$b=$_POST['id'];

if(isset($_REQUEST['Submit'])!='')
{
				
				$sqlf="select * from scrapmaster where id='".$b."'";
				$sqlg="select * from granualsmaster where id='".$b."'";
				$sqltg="select * from totalgranuals where id='".$b."'";
				$a1="";
				$p1="";
				$v1="";
				$result=0;
				$resultg=0;
				$resulttg=0;
				$result2=mysqli_query($conn,$sqlf);
				$result3=mysqli_query($conn,$sqlg);
				$result1=mysqli_query($conn,$sqltg);
				if(!$result2 or !$result3 or !$result1)
				{
					echo "invalid <br>";
				}
				else{
					while($r1=mysqli_fetch_array($result2))
					{
						
						$phone=$r1[0];
						$typee=$r1[1];
						$res=$r1[2];
					}
					while($r2=mysqli_fetch_array($result3))
					{
						$typeee=$r2[1];
						$resg=$r2[2];
					}
					while($r3=mysqli_fetch_array($result1))
					{
						$typetg=$r3[1];
						$restg=$r3[2];
					}
					}
				if($phone==$b)
					{
						$result=$resg+$res;
						$resulttg=$restg+$res;
						$sqlg="update granualsmaster set ton=".$result." where type='".$typee."'";
						$sqlff="update scrapmaster set ton=".$resultg." where type='".$typee."'";
						//$sqlttg="update totalgranuals set ton=".$resulttg." where type='".$typetg."'";						
						if ($conn->query($sqlff) === TRUE and $conn->query($sqlg) === TRUE) 
						{
							echo "<script> alert('Processed $typee successfully');document.location='process1.php'</script>";
						}
			    		else
						{
							echo "Not Processed successfully";
						}
					}
					else
					{
						echo "Please select proper choice";
					}
	
				}
				$conn->close();
?>