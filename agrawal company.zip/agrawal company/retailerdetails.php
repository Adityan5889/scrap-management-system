<?php
include 'config.php'; 
session_start();
$email=$_SESSION['retailer'];
if(isset($_REQUEST['Submit'])!='')
{
$st=$_POST['scraptype'];
$type=$_POST['tons'];
$date=date("y-m-d");
$ddate = date("d-m-Y", strtotime($date));
$ac=0;
$va=0;
$phone;
$sql1="select * from retailer where email ='".$email."'";

$result1=mysqli_query($conn,$sql1);
if(!$result1)
{
	echo "invalid <br>";
}
else{
	while($r=mysqli_fetch_array($result1))
	{
		$phone=$r[9];
	}	
}
	
$sql="insert into t$phone (type,ton,validate,datee) values('".$st."', '".$type."', '".$ac."', '".$ddate."')";
if ($conn->query($sql) === TRUE) {
	echo "<script> alert('Granuals Submited successfully');document.location='retailerdetailsl.php'</script>";
 } else {
    echo "Error: " . $sql . "<br>" . $conn->error;
	}
}

$conn->close();
?>