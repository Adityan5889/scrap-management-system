<?php
include 'config.php';

$a=$_POST['id'];
$e=$_POST['email'];
$m=$_POST['mobile'];
if(isset($_REQUEST['Submit'])!='')
{
				
				$sql="select * from employee where e_id ='".$a."'";
				$a1="";
				$p1="";
				$v1="";
				$result1=mysqli_query($conn,$sql);
				if(!$result1)
				{
					echo "invalid <br>";
				}
				else{
					while($r=mysqli_fetch_array($result1))
					{
						$a1=$r[0];
					}	
					}
				if($a1==$a)
					
					{
						$sql1="update employee set email='".$e."', mobile='".$m."' where e_id='".$a."'";
						if ($conn->query($sql1) === TRUE) 
						{
							//echo $sql1;
							echo "<script> alert('Employee Updated successfully');document.location='updateemployee.php'</script>";
			    		}
						else
						{
							echo "invalid";
							//echo $sql1;
						}
					}
					else
					{
						echo "Please enter correct email id";
					}
	
				}
				$conn->close();
?>