<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Select Scrap</title>

  <!-- Custom fonts for this template-->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

  <!-- Custom styles for this template-->
  <link href="css/sb-admin.css" rel="stylesheet">

</head>
<form method="post" action="scrapdetails.php">
<body class="bg-dark">
<form name="scrap details" method="POST" action="scrapdetails.php">
  <div class="container">
    <div class="card card-login mx-auto mt-5">
      <div class="card-header">Wel-come</div>
	  <div class="card-header"><?php echo "".$_SESSION['scraper'].""; ?></div>
      <div class="card-body">
        <form>
          <div class="form-group">
            <div class="form-label-group">  
			  <select name="scraptype">
			    <option disabled="disabled" selected="selected">...................................Select Scrap...................................</option>
				<option value="Plastic">Plastic</option>  
				<option value="Glass">Glass</option>
				<option value="EWaste">Electronic Waste</option>
				<option value="PaperWaste">Paper Waste</option>
			  </select>
            </div>
          </div>
          <div class="form-group">
            <div class="form-label-group">
              <input type="text" id="inputton" class="form-control" placeholder="Tons" required="required" name="tons">
              <label for="inputton">Ton</label>
            </div>
          </div>
          <input type="submit" class="btn btn-primary btn-block"	name="Submit"	value="Submit">
		  <a class="btn btn-primary btn-block" href="#" data-toggle="modal" data-target="#logoutModal">Logout</a>
      </div>
    </div>
  </div>
</form>


<div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
        <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
        <div class="modal-footer">
          <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
          <a class="btn btn-primary" href="scraperlogout.php">Logout</a>
        </div>
      </div>
    </div>
  </div>


  <!-- Bootstrap core JavaScript-->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

</body>

</html>
