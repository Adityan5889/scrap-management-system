<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require 'vendor/autoload.php';
$finalr="";
include 'config.php';
if(isset($_REQUEST['Submit'])!='')
{
	//++++++++otp++++++++++++++++
	function generateNumericOTP($n) { 
      
    // Take a generator string which consist of 
    // all numeric digits 
    $generator = "1357902468"; 
  
    // Iterate for n-times and pick a single character 
    // from generator and append it to $result 
      
    // Login for generating a random character from generator 
    //     ---generate a random number 
    //     ---take modulus of same with length of generator (say i) 
    //     ---append the character at place (i) from generator to result 
  
    $result = ""; 
  
    for ($i = 1; $i <= $n; $i++) { 
        $result .= substr($generator, (rand()%(strlen($generator))), 1); 
    } 
  
    // Return result 
    return $result; 
} 
  
// Main program 
$n = 6;
$finalr=(generateNumericOTP($n));
//echo $finalr; 	
	//+++++++++otp+++++++++++++++
	
	$ac=0;
    $va=0;
	
$sql="insert into retailer (fname,lname,cname, address, city, district, state, email, mobile, gst,password,otp,activate,validate) values('".$_REQUEST['fname']."','".$_REQUEST['lname']."','".$_REQUEST['company']."', '".$_REQUEST['address']."', '".$_REQUEST['city']."', '".$_REQUEST['district']."', '".$_REQUEST['state']."', '".$_REQUEST['email']."', '".$_REQUEST['mobile']."', '".$_REQUEST['gst']."','".$_REQUEST['pass']."', '".$finalr."', '".$ac."', '".$va."')";
if ($conn->query($sql) === TRUE) {
 //echo "New record created successfully";
 echo "<script> alert('Registration is Successful click OK to activate Account');document.location='activater.html'</script>";
 //echo ' <a href="activater.html">Click here for activate your account</a>';
 //echo "<a href="">Click here for activate your account</a>";
 //echo "New record created successfully";
 
 //*********email*********************
 $mail = new PHPMailer(true);

$mail->isSMTP();				// Set mailer to use SMTP
$mail->CharSet = "utf-8";		// set charset to utf8
$mail->SMTPAuth = true;			// Enable SMTP authentication
$mail->SMTPSecure = 'tls';		// Enable TLS encryption, `ssl` also accepted

$mail->Host = 'smtp.gmail.com';	// Specify main and backup SMTP servers
$mail->Port = 587;				// TCP port to connect to
$mail->SMTPOptions = array(
    'ssl' => array(
        'verify_peer' => false,
        'verify_peer_name' => false,
        'allow_self_signed' => true
    )
);
$mail->isHTML(true);			// Set email format to HTML

$mail->Username = 'agrawalcompany04@gmail.com';	// SMTP username
$mail->Password = 'AgrawalCompany04';					// SMTP password

$mail->setFrom('agrawalcompany04@gmail.com', 'Agrawal Company');	//Your application NAME and EMAIL
$mail->Subject = 'Your OTP is:';							//Message subject
$mail->MsgHTML($finalr);						// Message body
$mail->addAddress($_REQUEST['email'],$_REQUEST['fname']);// Target email


$mail->send();
 
 
 //********email*********************
 } else {
    echo "Error: " . $sql . "<br>" . $conn->error;
	}
}
$conn->close();
?>