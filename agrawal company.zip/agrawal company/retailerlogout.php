<?php
// Starting session
session_start();
 
// Removing session data
if(isset($_SESSION["retailer"])){
    unset($_SESSION["retailer"]);
	header('location:index.html');
}
?>