<?php
include 'config.php';
session_start(); 
if(isset($_REQUEST['Submit'])!='')
{
if($_REQUEST['email']==''|| $_REQUEST['pass']=='')
{
echo "please fill the empty field.";
}
else
{
	$a=$_REQUEST['email'];
	$b=$_REQUEST['pass'];
$sql="select * from retailer where email ='".$a."' AND password= '".$b."'";

$a1="";
$p1="";
//================================

$result1=mysqli_query($conn,$sql);
if(!$result1)
{
	echo "invalid <br>";
}
else{
	while($r=mysqli_fetch_array($result1))
	{
		$a1=$r[8];
		$p1=$r[11];
		$a2=$r[13];
		$v2=$r[14];
	}	
}
if($a1==$a and $p1==$b and $a2==1 and $v2==1)
	
	{
		echo "valid user";
		$_SESSION['retailer']=$_REQUEST['email'];
		header("Location:retailerdetailsl.php");
	}
	else
	{
		echo "Please enter correct username and password";
	}
}
}
$conn->close();
?>