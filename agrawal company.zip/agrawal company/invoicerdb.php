<?php
require ('fpdf/fpdf.php');
session_start();
$phone=$_SESSION['mobile'];
//db connection 
$con=mysqli_connect('localhost','root','');
mysqli_select_db($con,'scraper');

//get invoice data
$query=mysqli_query($con,"select * from t$phone where invcreid='".$_POST['id']."'");
$invoice=mysqli_fetch_array($query);

$query1=mysqli_query($con,"select * from retailer where mobile='".$phone."'");
$invoice1=mysqli_fetch_array($query1);

$query2=mysqli_query($con,"select * from pricelist where type='".$invoice['type']."'");
$invoice2=mysqli_fetch_array($query2);

$query3=mysqli_query($con,"select * from gst where type='".$invoice['type']."'");
$invoice3=mysqli_fetch_array($query3);

// A4 Width:219mm
// Default Margin : 10 mm each side
// writable horizontal: 219-(10*2)=189 mm

$pdf = new FPDF('P','mm','A4');
$pdf->AddPage();

//set font to aerial,bold,14pt
$pdf->SetFont('Arial','B',14);

//Cell (Width,height,text,border,endline,[align])
$pdf->Cell(130,5,'Agrawal & Company',0,0);
$pdf->Cell(59,5,'INVOICE',0,1);  // end of line

//set font to aerial,regular,12pt
$pdf->SetFont('Arial','',12);

//Cell (Width,height,text,border,endline,[align])
$pdf->Cell(130,5,'[Street Address]',0,0);
$pdf->Cell(59,5,'',0,1); // end of line

$pdf->Cell(130,5,'[City, Country, Zip]',0,0);
$pdf->Cell(30,5,'Date',0,0);
$pdf->Cell(34,5,$invoice['Datee'],0,1); // end of line

$pdf->Cell(130,5,'Phone [#9999999999]',0,0);
$pdf->Cell(30,5,'Invoice ID',0,0);
$pdf->Cell(34,5,$invoice['invcreid'],0,1); // end of line

$pdf->Cell(130,5,'Fax [#9999999999]',0,0);
$pdf->Cell(30,5,'Customer ID',0,0);
$pdf->Cell(34,5,$invoice1['reid'],0,1); // end of line

//make a dummy empty cell as a vertical spacer
$pdf->Cell(189,6,'',0,1);

//billing address
$pdf->Cell(100,10,'Bill To',0,1); //end of line

//add dummy cell at begining of each line for identification
$pdf->Cell(10,5,'',0,0);
$pdf->Cell(20,5,$invoice1['fname'],0,0);
$pdf->Cell(30,5,$invoice1['lname'],0,1);

$pdf->Cell(10,5,'',0,0);
$pdf->Cell(90,5,$invoice1['address'],0,1);

$pdf->Cell(10,5,'',0,0);
$pdf->Cell(15,5,$invoice1['city'],0,0);
$pdf->Cell(15,5,$invoice1['district'],0,0);
$pdf->Cell(60,5,$invoice1['state'],0,1);

$pdf->Cell(10,5,'',0,0);
$pdf->Cell(90,5,$invoice1['mobile'],0,1);
//$pdf->Cell(90,5,'[Phone]',0,1);

//make a dummy empty cell as a vertical spacer
$pdf->Cell(189,6,'',0,1);

//invoice content
$pdf->SetFont('Arial','B',12);
$prate=$invoice2['rate']+10;
$total=$prate*1000*$invoice['ton'];

$pdf->Cell(95,7,'Description',1,0);
$pdf->Cell(30,7,'Quantity / ton',1,0);
$pdf->Cell(30,7,'Rate / kg',1,0);
$pdf->Cell(34,7,'Amount',1,1); // end of line

$pdf->SetFont('Arial','',12);

//Numbers are right-aligned so we give 'R' after new line parameter


$pdf->Cell(95,9,$invoice['type'],1,0);
$pdf->Cell(30,9,$invoice['ton'],1,0);
$pdf->Cell(30,9,$prate,1,0);
$pdf->Cell(34,9,$total,1,1); // end of line

//Summery
//make a dummy empty cell as a vertical spacer
$pdf->Cell(189,5,'',0,1);

$pdf->Cell(120,6,'',0,0);
$pdf->Cell(26,6,'Subtotal',0,0);
$pdf->Cell(9,6,'Rs',1,0);
$pdf->Cell(34,6,$total,1,1,'R'); // end of line

$cgst=$total*$invoice3['rate']/100;

$pdf->Cell(120,6,'',0,0);
$pdf->Cell(26,6,'CGST',0,0);
$pdf->Cell(9,6,'Rs',1,0);
$pdf->Cell(34,6,$cgst,1,1,'R'); // end of line

$sgst=$total*$invoice3['rate']/100;

$pdf->Cell(120,6,'',0,0);
$pdf->Cell(26,6,'SGST',0,0);
$pdf->Cell(9,6,'Rs',1,0);
$pdf->Cell(34,6,$sgst,1,1,'R'); // end of line

$totaldue=$total+$cgst+$sgst;
$pdf->Cell(120,6,'',0,0);
$pdf->Cell(26,6,'Total Due',0,0);
$pdf->Cell(9,6,'Rs',1,0);
$pdf->Cell(34,6,$totaldue,1,1,'R'); // end of line

$pdf->Cell(60,7,'Receivers Signature',0,0);
$pdf->Cell(60,7,'Agrawal & Company',0,1);


//************************************************************
$pdf->Cell(189,25,'',0,1);
//set font to aerial,bold,14pt
$pdf->SetFont('Arial','B',14);

//Cell (Width,height,text,border,endline,[align])
$pdf->Cell(130,5,'Agrawal & Company',0,0);
$pdf->Cell(59,5,'INVOICE',0,1);  // end of line

//set font to aerial,regular,12pt
$pdf->SetFont('Arial','',12);

//Cell (Width,height,text,border,endline,[align])
$pdf->Cell(130,5,'[Street Address]',0,0);
$pdf->Cell(59,5,'',0,1); // end of line

$pdf->Cell(130,5,'[City, Country, Zip]',0,0);
$pdf->Cell(30,5,'Date',0,0);
$pdf->Cell(34,5,$invoice['Datee'],0,1); // end of line

$pdf->Cell(130,5,'Phone [#9999999999]',0,0);
$pdf->Cell(30,5,'Invoice ID',0,0);
$pdf->Cell(34,5,$invoice['invcreid'],0,1); // end of line

$pdf->Cell(130,5,'Fax [#9999999999]',0,0);
$pdf->Cell(30,5,'Customer ID',0,0);
$pdf->Cell(34,5,$invoice1['reid'],0,1); // end of line

//make a dummy empty cell as a vertical spacer
$pdf->Cell(189,6,'',0,1);

//billing address
$pdf->Cell(100,10,'Bill To',0,1); //end of line

//add dummy cell at begining of each line for identification
$pdf->Cell(10,5,'',0,0);
$pdf->Cell(20,5,$invoice1['fname'],0,0);
$pdf->Cell(30,5,$invoice1['lname'],0,1);

$pdf->Cell(10,5,'',0,0);
$pdf->Cell(90,5,$invoice1['address'],0,1);

$pdf->Cell(10,5,'',0,0);
$pdf->Cell(15,5,$invoice1['city'],0,0);
$pdf->Cell(15,5,$invoice1['district'],0,0);
$pdf->Cell(60,5,$invoice1['state'],0,1);

$pdf->Cell(10,5,'',0,0);
$pdf->Cell(90,5,$invoice1['mobile'],0,1);
//$pdf->Cell(90,5,'[Phone]',0,1);

//make a dummy empty cell as a vertical spacer
$pdf->Cell(189,6,'',0,1);

//invoice content
$pdf->SetFont('Arial','B',12);
$prate=$invoice2['rate']+10;
$total=$prate*1000*$invoice['ton'];

$pdf->Cell(95,7,'Description',1,0);
$pdf->Cell(30,7,'Quantity / ton',1,0);
$pdf->Cell(30,7,'Rate / kg',1,0);
$pdf->Cell(34,7,'Amount',1,1); // end of line

$pdf->SetFont('Arial','',12);

//Numbers are right-aligned so we give 'R' after new line parameter


$pdf->Cell(95,9,$invoice['type'],1,0);
$pdf->Cell(30,9,$invoice['ton'],1,0);
$pdf->Cell(30,9,$prate,1,0);
$pdf->Cell(34,9,$total,1,1); // end of line

//Summery
//make a dummy empty cell as a vertical spacer
$pdf->Cell(189,5,'',0,1);

$pdf->Cell(120,6,'',0,0);
$pdf->Cell(26,6,'Subtotal',0,0);
$pdf->Cell(9,6,'Rs',1,0);
$pdf->Cell(34,6,$total,1,1,'R'); // end of line

$cgst=$total*$invoice3['rate']/100;

$pdf->Cell(120,6,'',0,0);
$pdf->Cell(26,6,'CGST',0,0);
$pdf->Cell(9,6,'Rs',1,0);
$pdf->Cell(34,6,$cgst,1,1,'R'); // end of line

$sgst=$total*$invoice3['rate']/100;

$pdf->Cell(120,6,'',0,0);
$pdf->Cell(26,6,'SGST',0,0);
$pdf->Cell(9,6,'Rs',1,0);
$pdf->Cell(34,6,$sgst,1,1,'R'); // end of line

$totaldue=$total+$cgst+$sgst;
$pdf->Cell(120,6,'',0,0);
$pdf->Cell(26,6,'Total Due',0,0);
$pdf->Cell(9,6,'Rs',1,0);
$pdf->Cell(34,6,$totaldue,1,1,'R'); // end of line

$pdf->Cell(60,7,'Receivers Signature',0,0);
$pdf->Cell(60,7,'Agrawal & Company',0,1);


//************************************************************

$pdf->Output();
?>
