-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Feb 27, 2019 at 12:57 PM
-- Server version: 10.1.9-MariaDB
-- PHP Version: 5.5.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `scrapper`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `username` varchar(15) NOT NULL,
  `password` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`username`, `password`) VALUES
('admin', 'admin'),
('omkar', 'omkar'),
('mohini', 'mohini');

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `e_id` int(11) NOT NULL,
  `fname` varchar(20) DEFAULT NULL,
  `lname` varchar(3) DEFAULT NULL,
  `address` varchar(40) DEFAULT NULL,
  `city` varchar(20) DEFAULT NULL,
  `district` varchar(20) DEFAULT NULL,
  `pan` varchar(10) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `mobile` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `granualsmaster`
--

CREATE TABLE `granualsmaster` (
  `id` int(11) NOT NULL,
  `type` varchar(25) NOT NULL,
  `ton` int(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `granualsmaster`
--

INSERT INTO `granualsmaster` (`id`, `type`, `ton`) VALUES
(1, 'Plastic', 7),
(2, 'Glass', 4),
(3, 'EWaste', 2),
(4, 'PaperWaste', 3);

-- --------------------------------------------------------

--
-- Table structure for table `retailer`
--

CREATE TABLE `retailer` (
  `r_id` int(11) NOT NULL,
  `fname` varchar(20) DEFAULT NULL,
  `lname` varchar(3) DEFAULT NULL,
  `cname` varchar(50) DEFAULT NULL,
  `address` varchar(40) DEFAULT NULL,
  `city` varchar(20) DEFAULT NULL,
  `district` varchar(20) DEFAULT NULL,
  `state` varchar(20) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `mobile` varchar(10) DEFAULT NULL,
  `gst` varchar(20) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL,
  `otp` varchar(6) DEFAULT NULL,
  `activate` int(1) DEFAULT NULL,
  `validate` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `retailer`
--

INSERT INTO `retailer` (`r_id`, `fname`, `lname`, `cname`, `address`, `city`, `district`, `state`, `email`, `mobile`, `gst`, `password`, `otp`, `activate`, `validate`) VALUES
(1, 'omkar', 'uru', 'eworld', 'satara', 'satara', 'satara', 'maharashtra', 'urunkarsir@gmail.com', '9604296965', '2222222', '123', '642724', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `scraper`
--

CREATE TABLE `scraper` (
  `s_id` int(11) NOT NULL,
  `fname` varchar(20) DEFAULT NULL,
  `lname` varchar(3) DEFAULT NULL,
  `address` varchar(40) DEFAULT NULL,
  `city` varchar(20) DEFAULT NULL,
  `district` varchar(20) DEFAULT NULL,
  `state` varchar(20) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `mobile` varchar(10) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL,
  `otp` varchar(6) DEFAULT NULL,
  `activate` int(1) DEFAULT NULL,
  `validate` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `scraper`
--

INSERT INTO `scraper` (`s_id`, `fname`, `lname`, `address`, `city`, `district`, `state`, `email`, `mobile`, `password`, `otp`, `activate`, `validate`) VALUES
(1, 'mohini', 'mah', 'kolhapur', 'kolhapur', 'kolhapur', 'maharashtra', 'urunkaromkar123@gmail.com', '7020146083', '123', '579893', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `scrapmaster`
--

CREATE TABLE `scrapmaster` (
  `id` int(11) NOT NULL,
  `type` varchar(25) DEFAULT NULL,
  `ton` int(3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `scrapmaster`
--

INSERT INTO `scrapmaster` (`id`, `type`, `ton`) VALUES
(1, 'Plastic', 0),
(2, 'Glass', 0),
(3, 'EWaste', 0),
(4, 'PaperWaste', 0);

-- --------------------------------------------------------

--
-- Table structure for table `t7020146083`
--

CREATE TABLE `t7020146083` (
  `id` int(11) NOT NULL,
  `type` varchar(20) DEFAULT NULL,
  `ton` int(3) DEFAULT NULL,
  `validate` int(1) DEFAULT NULL,
  `Datee` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `t7020146083`
--

INSERT INTO `t7020146083` (`id`, `type`, `ton`, `validate`, `Datee`) VALUES
(1, 'Plastic', 0, 0, '27-02-2019'),
(2, 'Glass', 3, 0, '27-02-2019'),
(3, 'PaperWaste', 4, 0, '27-02-2019');

-- --------------------------------------------------------

--
-- Table structure for table `t9604296965`
--

CREATE TABLE `t9604296965` (
  `id` int(11) NOT NULL,
  `type` varchar(20) DEFAULT NULL,
  `ton` int(3) DEFAULT NULL,
  `validate` int(1) DEFAULT NULL,
  `Datee` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `t9604296965`
--

INSERT INTO `t9604296965` (`id`, `type`, `ton`, `validate`, `Datee`) VALUES
(1, 'Glass', 2, 0, '27-02-2019'),
(2, 'EWaste', 2, 0, '27-02-2019');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`e_id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `mobile` (`mobile`);

--
-- Indexes for table `granualsmaster`
--
ALTER TABLE `granualsmaster`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `retailer`
--
ALTER TABLE `retailer`
  ADD PRIMARY KEY (`r_id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `mobile` (`mobile`),
  ADD UNIQUE KEY `gst` (`gst`);

--
-- Indexes for table `scraper`
--
ALTER TABLE `scraper`
  ADD PRIMARY KEY (`s_id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `mobile` (`mobile`);

--
-- Indexes for table `scrapmaster`
--
ALTER TABLE `scrapmaster`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `type` (`type`);

--
-- Indexes for table `t7020146083`
--
ALTER TABLE `t7020146083`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `t9604296965`
--
ALTER TABLE `t9604296965`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `e_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `granualsmaster`
--
ALTER TABLE `granualsmaster`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `retailer`
--
ALTER TABLE `retailer`
  MODIFY `r_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `scraper`
--
ALTER TABLE `scraper`
  MODIFY `s_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `scrapmaster`
--
ALTER TABLE `scrapmaster`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `t7020146083`
--
ALTER TABLE `t7020146083`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `t9604296965`
--
ALTER TABLE `t9604296965`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
