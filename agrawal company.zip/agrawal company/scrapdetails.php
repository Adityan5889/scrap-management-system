<?php
include 'config.php'; 
session_start();
$email=$_SESSION['scraper'];
if(isset($_REQUEST['Submit'])!='')
{
$st=$_POST['scraptype'];
$date=date("y-m-d");
$ddate = date("d-m-Y", strtotime($date));
$type=$_POST['tons'];
$ac=0;
$va=0;
$phone;
$sql1="select * from scraper where email ='".$email."'";

$result1=mysqli_query($conn,$sql1);
if(!$result1)
{
	echo "invalid <br>";
}
else{
	while($r=mysqli_fetch_array($result1))
	{
		$phone=$r[8];
	}	
}
	
$sql="insert into t$phone (type,ton,validate,datee) values('".$st."', '".$type."', '".$ac."', '".$ddate."')";
if ($conn->query($sql) === TRUE) {
	echo "<script> alert('Scrap Added successfully');document.location='scrapsetailsl.php'</script>";
     //echo $ddate;
 } else {
    echo "Error: " . $sql . "<br>" . $conn->error;
	}
}

$conn->close();
?>