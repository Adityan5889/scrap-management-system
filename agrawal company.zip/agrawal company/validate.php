<?php
include 'config.php';
$a=$_POST['email'];
if(isset($_REQUEST['Submit'])!='')
{
				$a=$_POST['email'];
				$sql="select * from scraper where email ='".$a."'";
				$a1="";
				$p1="";
				$v1="";
				$result1=mysqli_query($conn,$sql);
				if(!$result1)
				{
					echo "invalid <br>";
				}
				else{
					while($r=mysqli_fetch_array($result1))
					{
						$a1=$r[7];
						$phone=$r[8];
						$p1=$r[11];
						$id=$r[0];
					}	
					}
					$scid="SCRP0".$id;
				if($a1==$a AND $p1==1)
					{
						$sql1="update scraper set validate='".$p1."',scid='".$scid."' where email='".$a1."'";
						$name = mysql_real_escape_string($phone);
						$sqle="create table t$name (id int auto_increment, type varchar(20), ton int(3), validate int(1), Datee text, invcscid varchar(15),primary key(id))";
						if ($conn->query($sql1) === TRUE and $conn->query($sqle) === TRUE) 
						{
							echo "<script> alert('Account validated successfully');document.location='scrapervalidation.php'</script>";
			    		}
						else
						{
							echo "Account not validated successfully";
						}
					}
					else
					{
						echo "Please enter correct email id";
					}
				}
				$conn->close();
?>