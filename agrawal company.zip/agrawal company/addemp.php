<?php
include 'config.php';
$sql1="select MAX(e_id) from employee";
$result1=mysqli_query($conn,$sql1);
$row = mysqli_fetch_row($result1);
$att=$row[0];
if($att=="NULL")
{
	$att=1;
	$ae_id="AEID0".$att;
}
else
{
	$att=$att+1;
	$ae_id="AEID0".$att;
}
if(isset($_REQUEST['Submit'])!='')
	$sql="insert into employee (fname,lname,address, city, district, pan, email, mobile,ae_id) values('".$_REQUEST['fname']."','".$_REQUEST['lname']."', '".$_REQUEST['address']."', '".$_REQUEST['city']."', '".$_REQUEST['district']."', '".$_REQUEST['pan']."', '".$_REQUEST['email']."', '".$_REQUEST['mobile']."','".$ae_id."')";
		if ($conn->query($sql) === TRUE) {
	echo "<script> alert('Employee Added successfully');document.location='adminpanel.html'</script>";
  } else {
    echo "Error: " . $sql . "<br>" . $conn->error;
	}

$conn->close();
?>