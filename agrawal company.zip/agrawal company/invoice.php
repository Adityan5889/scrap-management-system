<?php
require ('fpdf/fpdf.php');

// A4 Width:219mm
// Default Margin : 10 mm each side
// writable horizontal: 219-(10*2)=189 mm

$pdf = new FPDF('P','mm','A4');
$pdf->AddPage();

//set font to aerial,bold,14pt
$pdf->SetFont('Arial','B',14);

//Cell (Width,height,text,border,endline,[align])
$pdf->Cell(130,5,'Agrawal & Company',0,0);
$pdf->Cell(59,5,'INVOICE',0,1);  // end of line

//set font to aerial,regular,12pt
$pdf->SetFont('Arial','',12);

//Cell (Width,height,text,border,endline,[align])
$pdf->Cell(130,5,'[Street Address]',0,0);
$pdf->Cell(59,5,'',0,1); // end of line

$pdf->Cell(130,5,'[City, Country, Zip]',0,0);
$pdf->Cell(25,5,'Date',0,0);
$pdf->Cell(34,5,'[dd/mm/yyyy]',0,1); // end of line

$pdf->Cell(130,5,'Phone [#9999999999]',0,0);
$pdf->Cell(25,5,'Invoice #',0,0);
$pdf->Cell(34,5,'[123456789]',0,1); // end of line

$pdf->Cell(130,5,'Fax [#9999999999]',0,0);
$pdf->Cell(25,5,'Customer ID #',0,0);
$pdf->Cell(34,5,'[123456789]',0,1); // end of line

//make a dummy empty cell as a vertical spacer
$pdf->Cell(189,10,'',0,1);

//billing address
$pdf->Cell(100,10,'Bill To',0,1); //end of line

//add dummy cell at begining of each line for identification
$pdf->Cell(10,5,'',0,0);
$pdf->Cell(90,5,'[Name]',0,1);

$pdf->Cell(10,5,'',0,0);
$pdf->Cell(90,5,'[Company Name]',0,1);

$pdf->Cell(10,5,'',0,0);
$pdf->Cell(90,5,'[Address]',0,1);

$pdf->Cell(10,5,'',0,0);
$pdf->Cell(90,5,'[Phone]',0,1);

//make a dummy empty cell as a vertical spacer
$pdf->Cell(189,10,'',0,1);

//invoice content
$pdf->SetFont('Arial','B',12);

$pdf->Cell(105,5,'Description',1,0);
$pdf->Cell(25,5,'Quantity',1,0);
$pdf->Cell(25,5,'Rate',1,0);
$pdf->Cell(34,5,'Amount',1,1); // end of line

$pdf->SetFont('Arial','',12);

//Numbers are right-aligned so we give 'R' after new line parameter

$pdf->Cell(105,5,'Monitor',1,0);
$pdf->Cell(25,5,'-',1,0);
$pdf->Cell(25,5,'-',1,0);
$pdf->Cell(34,5,'12,500',1,1); // end of line

$pdf->Cell(105,5,'Keyboard',1,0);
$pdf->Cell(25,5,'-',1,0);
$pdf->Cell(25,5,'-',1,0);
$pdf->Cell(34,5,'15000',1,1); // end of line

$pdf->Cell(105,5,'Mouse',1,0);
$pdf->Cell(25,5,'-',1,0);
$pdf->Cell(25,5,'-',1,0);
$pdf->Cell(34,5,'12000',1,1); // end of line


//Summery
//make a dummy empty cell as a vertical spacer
$pdf->Cell(189,10,'',0,1);

$pdf->Cell(130,5,'',0,0);
$pdf->Cell(25,5,'Subtotal',0,0);
$pdf->Cell(9,5,'Rs',1,0);
$pdf->Cell(25,5,'30000',1,1,'R'); // end of line

$pdf->Cell(130,5,'',0,0);
$pdf->Cell(25,5,'CGST',0,0);
$pdf->Cell(9,5,'Rs',1,0);
$pdf->Cell(25,5,'1000',1,1,'R'); // end of line

$pdf->Cell(130,5,'',0,0);
$pdf->Cell(25,5,'SGST',0,0);
$pdf->Cell(9,5,'Rs',1,0);
$pdf->Cell(25,5,'1000',1,1,'R'); // end of line

$pdf->Cell(130,5,'',0,0);
$pdf->Cell(25,5,'Total Due',0,0);
$pdf->Cell(9,5,'Rs',1,0);
$pdf->Cell(25,5,'10000',1,1,'R'); // end of line


//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//make a dummy empty cell as a vertical spacer
$pdf->Cell(189,10,'',0,1);

// A4 Width:219mm
// Default Margin : 10 mm each side
// writable horizontal: 219-(10*2)=189 mm

//set font to aerial,bold,14pt
$pdf->SetFont('Arial','B',14);

//Cell (Width,height,text,border,endline,[align])
$pdf->Cell(130,5,'Agrawal & Company',0,0);
$pdf->Cell(59,5,'INVOICE',0,1);  // end of line

//set font to aerial,regular,12pt
$pdf->SetFont('Arial','',12);

//Cell (Width,height,text,border,endline,[align])
$pdf->Cell(130,5,'[Street Address]',0,0);
$pdf->Cell(59,5,'',0,1); // end of line

$pdf->Cell(130,5,'[City, Country, Zip]',0,0);
$pdf->Cell(25,5,'Date',0,0);
$pdf->Cell(34,5,'[dd/mm/yyyy]',0,1); // end of line

$pdf->Cell(130,5,'Phone [#9999999999]',0,0);
$pdf->Cell(25,5,'Invoice #',0,0);
$pdf->Cell(34,5,'[123456789]',0,1); // end of line

$pdf->Cell(130,5,'Fax [#9999999999]',0,0);
$pdf->Cell(25,5,'Customer ID #',0,0);
$pdf->Cell(34,5,'[123456789]',0,1); // end of line

//make a dummy empty cell as a vertical spacer
$pdf->Cell(189,10,'',0,1);

//billing address
$pdf->Cell(100,10,'Bill To',0,1); //end of line

//add dummy cell at begining of each line for identification
$pdf->Cell(10,5,'',0,0);
$pdf->Cell(90,5,'[Name]',0,1);

$pdf->Cell(10,5,'',0,0);
$pdf->Cell(90,5,'[Company Name]',0,1);

$pdf->Cell(10,5,'',0,0);
$pdf->Cell(90,5,'[Address]',0,1);

$pdf->Cell(10,5,'',0,0);
$pdf->Cell(90,5,'[Phone]',0,1);

//make a dummy empty cell as a vertical spacer
$pdf->Cell(189,10,'',0,1);

//invoice content
$pdf->SetFont('Arial','B',12);

$pdf->Cell(105,5,'Description',1,0);
$pdf->Cell(25,5,'Quantity',1,0);
$pdf->Cell(25,5,'Rate',1,0);
$pdf->Cell(34,5,'Amount',1,1); // end of line

$pdf->SetFont('Arial','',12);

//Numbers are right-aligned so we give 'R' after new line parameter

$pdf->Cell(105,5,'Monitor',1,0);
$pdf->Cell(25,5,'-',1,0);
$pdf->Cell(25,5,'-',1,0);
$pdf->Cell(34,5,'12,500',1,1); // end of line

$pdf->Cell(105,5,'Keyboard',1,0);
$pdf->Cell(25,5,'-',1,0);
$pdf->Cell(25,5,'-',1,0);
$pdf->Cell(34,5,'15000',1,1); // end of line

$pdf->Cell(105,5,'Mouse',1,0);
$pdf->Cell(25,5,'-',1,0);
$pdf->Cell(25,5,'-',1,0);
$pdf->Cell(34,5,'12000',1,1); // end of line


//Summery
//make a dummy empty cell as a vertical spacer
$pdf->Cell(189,10,'',0,1);

$pdf->Cell(130,5,'',0,0);
$pdf->Cell(25,5,'Subtotal',0,0);
$pdf->Cell(9,5,'Rs',1,0);
$pdf->Cell(25,5,'30000',1,1,'R'); // end of line

$pdf->Cell(130,5,'',0,0);
$pdf->Cell(25,5,'CGST',0,0);
$pdf->Cell(9,5,'Rs',1,0);
$pdf->Cell(25,5,'1000',1,1,'R'); // end of line

$pdf->Cell(130,5,'',0,0);
$pdf->Cell(25,5,'SGST',0,0);
$pdf->Cell(9,5,'Rs',1,0);
$pdf->Cell(25,5,'1000',1,1,'R'); // end of line

$pdf->Cell(130,5,'',0,0);
$pdf->Cell(25,5,'Total Due',0,0);
$pdf->Cell(9,5,'Rs',1,0);
$pdf->Cell(25,5,'10000',1,1,'R'); // end of line

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
$pdf->Output();
?>
