<?php
include 'config.php';
session_start();
$a=$_SESSION['mobile'];

$b=$_POST['id'];
$c=$_POST['type'];
if(isset($_REQUEST['Submit'])!='')
{
				
				$sql="select * from t$a where id ='".$b."'";
				$sqlg="select * from granualsmaster where type='".$c."'";
				$sqltg="select * from totalgranuals where type='".$c."'";
				$a1="";
				$p1="";
				$v1="";
				$result=0;
				$resultg=0;
				$resultt=0;
				$result1=mysqli_query($conn,$sql);
				$result3=mysqli_query($conn,$sqlg);
				$result2=mysqli_query($conn,$sqltg);
				if(!$result1)
				{
					echo "invalid <br>";
				}
				else{
					while($r=mysqli_fetch_array($result1))
					{
						$phone=$r[0];
						$t=$r[1];
						$a1=$r[2];
					}	
					while($r2=mysqli_fetch_array($result3))
					{
						$typeee=$r2[1];
						$resg=$r2[2];
					}
					while($r3=mysqli_fetch_array($result2))
					{
						$typee=$r3[1];
						$restg=$r3[2];
					}
					}
					$invid="INVCREID0".$phone;
				if($t==$c)
					
					{
						
						$resultg=$resg-$a1;
						$resultt=$restg+$a1;
						$sql1="update t$a set validate='1', invcreid='".$invid."' where id='".$b."'";
						$sqlg="update granualsmaster set ton=".$resultg." where type='".$typeee."'";
						$sqlff="update totalgranuals set ton=".$resultt." where type='".$typeee."'";
						//echo $sql1;
						//echo $sqlg;
						//echo $sqlff;
						if ($conn->query($sqlg) === TRUE and $conn->query($sql1) === TRUE and $conn->query($sqlff) === TRUE) 
						{
							echo "<script> alert('Granuals $c validated successfully');document.location='final_rscrap_validation.php'</script>";
						}
			    		else
						{
							echo "Account not validated successfully";
						}
					}
					else
					{
						echo "Please enter correct email id";
					}
	
				}
				$conn->close();
?>