<?php
include 'config.php';
				if(isset($_REQUEST['Submit'])!='')
				{
					$att=$_POST['attendance'];
					$ae_id=$_POST['ae_id'];
					echo $att;
					$date=date('Y-m-d');
					
					$query="select distinct datee from attendance where ae_id='".$ae_id."'";
					$result=mysqli_query($conn,$query);
					$num_rows = mysqli_num_rows($result);
					echo $num_rows;
					$b=false;
					$f=false;
					if($num_rows>0)
					{
						while($check=$result->fetch_assoc())
						{
							if($date==$check['datee'])
							{
								$b=true;
								echo "<script> alert('Attendance already taken');document.location='dailyatt.php'</script>";
							}
						}
					}
						if(!$b)
						{
							        $f=true;
									$resultt="insert into attendance(value,datee,flag,ae_id)values ('$att','$date',$f,'$ae_id')";
									echo $resultt;
									if ($conn->query($resultt) === TRUE)
									{
									  echo "<script> alert('Attendance taken Successfully');document.location='dailyatt.php'</script>";
									}
								
						}
					
				}
				?>